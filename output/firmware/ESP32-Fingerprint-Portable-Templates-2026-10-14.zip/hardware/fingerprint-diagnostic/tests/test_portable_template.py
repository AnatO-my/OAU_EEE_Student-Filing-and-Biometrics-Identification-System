"""Synthetic records and serial transcripts; no hardware or real biometrics."""
import base64
from dataclasses import asdict, replace
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import time
import unittest
from unittest.mock import patch
import zlib

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "tools"))
import portable_template as fp

STUDENT = "11111111-1111-4111-8111-111111111111"
SCANNER = "22222222-2222-4222-8222-222222222222"
GALLERY = "33333333-3333-4333-8333-333333333333"
TEMPLATE = "44444444-4444-4444-8444-444444444444"
DATA = bytes(range(256)) + bytes(range(44))
PARAMETERS = dict(slot_id=1, capacity=150, security_level=3, packet_bytes=128,
                  system_id=0, device_address="FFFFFFFF")


class FakePort:
    def __init__(self, lines):
        self.lines = list(lines)
        self.writes = []

    def readline(self, _limit):
        return self.lines.pop(0) if self.lines else b""

    def write(self, value):
        self.writes.append(value)

    def flush(self):
        pass


def record():
    return fp.FingerprintTemplateRecord.create(
        DATA, student_id=STUDENT, finger_label="right_index", scanner_id=SCANNER,
        gallery_id=GALLERY, compatibility_group="as608-unit-1", parameters=PARAMETERS,
        template_id=TEMPLATE,
    )


def transcript():
    lines = [b"unrelated report line\n", b"FPBEGIN 1 1 150 3 128 0 FFFFFFFF\n"]
    lines.extend(("FPDATA " + DATA[i:i + 32].hex() + "\n").encode()
                 for i in range(0, len(DATA), 32))
    lines.append(f"FPEND {len(DATA)} {zlib.crc32(DATA):08X}\n".encode())
    return lines


class PortableTemplateTests(unittest.TestCase):
    def test_record_round_trip_and_stable_identity(self):
        original = record()
        restored = fp.FingerprintTemplateRecord(**json.loads(json.dumps(asdict(original))))
        self.assertEqual(restored.validated_bytes(), DATA)
        self.assertEqual(restored.template_id, TEMPLATE)
        self.assertEqual(restored.student_id, STUDENT)
        self.assertEqual(restored.source["slot_id"], 1)
        self.assertEqual(restored.template_sha256, hashlib.sha256(DATA).hexdigest())

    def test_invalid_records_are_rejected(self):
        for changes in (
            dict(schema_version=True), dict(schema_version=2), dict(student_id="1"),
            dict(template_id="00000000-0000-0000-0000-000000000000"),
            dict(template_format="unknown"), dict(byte_length=299),
            dict(template_sha256="0" * 64), dict(template_base64="invalid@"),
            dict(template_base64=base64.b64encode(b"X" * 2049).decode()),
            dict(finger_label="right index"), dict(compatibility_group=""),
        ):
            with self.subTest(changes=changes), self.assertRaises((ValueError, TypeError)):
                replace(record(), **changes).validated_bytes()

    def test_file_bounds_and_no_overwrite(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "synthetic.fpt.json"
            with path.open("x", encoding="utf-8") as stream:
                fp.write_json(stream, asdict(record()))
            self.assertEqual(fp.read_record(path).validated_bytes(), DATA)
            with self.assertRaises(FileExistsError):
                path.open("x", encoding="utf-8")
            path.write_text(" " * 16385)
            with self.assertRaises(ValueError):
                fp.read_record(path)

    def test_export_transcript(self):
        data, parameters = fp.receive_export(FakePort(transcript()), deadline=time.monotonic() + 1)
        self.assertEqual(data, DATA)
        self.assertEqual(parameters, PARAMETERS)

    def test_export_corruption_and_partial_data(self):
        variants = []
        lines = transcript(); lines[-1] = b"FPEND 300 00000000\n"; variants.append(lines)
        lines = transcript(); lines[2] = b"FPDATA GG\n"; variants.append(lines)
        lines = transcript(); lines[-1] = b"FPEND 299 00000000\n"; variants.append(lines)
        lines = transcript(); lines[-1] = b"FPERROR timeout\n"; variants.append(lines)
        lines = transcript(); lines[1] = b"FPBEGIN 2 1 150 3 128 0 FFFFFFFF\n"; variants.append(lines)
        lines = transcript(); lines[2] = b"FPDATA 0"; variants.append(lines)
        lines = [b"FPBEGIN 1 1 150 3 128 0 FFFFFFFF\n"] + [b"FPDATA " + b"00" * 32 + b"\n"] * 65
        variants.append(lines)
        for lines in variants:
            with self.subTest(lines=lines[-1]), self.assertRaises(ValueError):
                fp.receive_export(FakePort(lines), deadline=time.monotonic() + 1)

    @patch.object(fp.time, "sleep")
    def test_restore_receipt_and_sent_bytes(self, _sleep):
        checksum = zlib.crc32(DATA)
        port = FakePort([b"FPREADY 2 300\n", f"FPSTORED 2 300 {checksum:08X}\n".encode()])
        planned = []
        slot = fp.restore_bytes(port, DATA, deadline=time.monotonic() + 1, on_ready=planned.append)
        self.assertEqual(planned, [2])
        self.assertEqual(slot, 2)
        self.assertEqual(port.writes[0], f"u 300 {checksum:08X}\n".encode())
        self.assertEqual(bytes.fromhex(b"".join(port.writes[1:]).decode()), DATA)

    @patch.object(fp.time, "sleep")
    def test_restore_failure_has_no_verified_result(self, _sleep):
        for lines in ([b"FPERROR full\n"], [b"FPREADY 2 299\n"],
                      [b"FPREADY 2 300\n", b"FPERROR checksum\n"],
                      [b"FPREADY 2 300\n", b"FPSTORED 3 300 00000000\n"]):
            with self.subTest(lines=lines), self.assertRaises(ValueError):
                fp.restore_bytes(FakePort(lines), DATA, deadline=time.monotonic() + 1)

    def test_pending_receipt_remains_when_restore_fails(self):
        # The CLI creates/fsyncs pending metadata before connection/mutation.
        with tempfile.TemporaryDirectory() as folder:
            package = Path(folder) / "synthetic.fpt.json"
            package.write_text(json.dumps(asdict(record())))
            receipt = Path(folder) / "pending.receipt.json"
            argv = ["portable_template.py", "restore", "--port", "FAKE", "--record", str(package),
                    "--target-scanner-id", SCANNER, "--target-gallery-id", GALLERY,
                    "--compatibility-group", "as608-unit-1", "--receipt", str(receipt)]
            with patch.object(sys, "argv", argv), patch.object(fp, "connect", side_effect=OSError("offline")):
                with self.assertRaises(OSError):
                    fp.main()
            self.assertEqual(json.loads(receipt.read_text())["status"], "pending")
            self.assertEqual(json.loads(receipt.read_text())["template_id"], TEMPLATE)

    def test_incompatible_group_stops_before_connection(self):
        with tempfile.TemporaryDirectory() as folder:
            package = Path(folder) / "synthetic.fpt.json"
            package.write_text(json.dumps(asdict(record())))
            argv = ["portable_template.py", "restore", "--port", "FAKE", "--record", str(package),
                    "--target-scanner-id", SCANNER, "--target-gallery-id", GALLERY,
                    "--compatibility-group", "other", "--receipt", str(Path(folder) / "receipt.json")]
            with patch.object(sys, "argv", argv), patch.object(fp, "connect") as connect:
                with self.assertRaises(ValueError):
                    fp.main()
                connect.assert_not_called()


if __name__ == "__main__":
    unittest.main()
