#include <Arduino.h>
#include "config.h"
#include "fingerprint_protocol.h"

using fingerprint::Reply;
// UART1 is available on both the original ESP32 and ESP32-S3. UART0 remains
// available for the board's USB-to-UART console. Pins are assigned explicitly.
HardwareSerial scanner(1);
uint32_t connectedBaud = 0;
bool authenticated = false;

enum class QueryError { None, Timeout, InvalidFrame };
struct QueryResult {
  QueryError error = QueryError::None;
  fingerprint::FrameError frameError = fingerprint::FrameError::None;
  Reply reply;
};

bool readByte(uint8_t &value, uint32_t started, uint32_t timeoutMs) {
  while (static_cast<uint32_t>(millis() - started) < timeoutMs) {
    if (scanner.available()) {
      value = static_cast<uint8_t>(scanner.read());
      return true;
    }
    delay(1);
  }
  return false;
}

QueryResult query(const uint8_t *command, size_t length,
                  uint32_t timeoutMs = REPLY_TIMEOUT_MS) {
  QueryResult result;
  uint8_t frame[fingerprint::MAX_FRAME_SIZE] = {};
  const size_t requestSize = fingerprint::encodeCommand(
      frame, sizeof(frame), FINGERPRINT_ADDRESS, command, length);
  if (!requestSize) {
    result.error = QueryError::InvalidFrame;
    result.frameError = fingerprint::FrameError::Length;
    return result;
  }
  while (scanner.available()) {
    scanner.read();
  }
  scanner.write(frame, requestSize);
  scanner.flush();
  const uint32_t started = millis();

  // Ignore startup noise until an EF01 header is found, with one total timeout.
  bool haveEF = false;
  uint8_t byte = 0;
  while (true) {
    if (!readByte(byte, started, timeoutMs)) {
      result.error = QueryError::Timeout;
      return result;
    }
    if (haveEF && byte == 0x01) {
      frame[0] = 0xEF;
      frame[1] = 0x01;
      break;
    }
    haveEF = (byte == 0xEF);
  }
  for (size_t i = 2; i < fingerprint::HEADER_SIZE; ++i) {
    if (!readByte(frame[i], started, timeoutMs)) {
      result.error = QueryError::Timeout;
      return result;
    }
  }
  const size_t bodySize = fingerprint::read16(frame + 7);
  if (bodySize < 3 || bodySize > sizeof(frame) - fingerprint::HEADER_SIZE) {
    result.error = QueryError::InvalidFrame;
    result.frameError = fingerprint::FrameError::Length;
    return result;
  }
  const size_t frameSize = fingerprint::HEADER_SIZE + bodySize;
  for (size_t i = fingerprint::HEADER_SIZE; i < frameSize; ++i) {
    if (!readByte(frame[i], started, timeoutMs)) {
      result.error = QueryError::Timeout;
      return result;
    }
  }
  result.frameError = fingerprint::decodeAck(
      frame, frameSize, FINGERPRINT_ADDRESS, result.reply);
  if (result.frameError != fingerprint::FrameError::None) {
    result.error = QueryError::InvalidFrame;
  }
  return result;
}

const char *frameErrorText(fingerprint::FrameError error) {
  switch (error) {
  case fingerprint::FrameError::Length: return "invalid packet length";
  case fingerprint::FrameError::Header: return "invalid packet header";
  case fingerprint::FrameError::Address: return "unexpected device address";
  case fingerprint::FrameError::PacketType: return "expected an ACK packet";
  case fingerprint::FrameError::Checksum: return "checksum mismatch";
  default: return "OK";
  }
}

bool checkQuery(const char *name, const QueryResult &result) {
  if (result.error == QueryError::Timeout) {
    Serial.printf("%s: timeout (no complete EF01 response).\n", name);
    return false;
  }
  if (result.error == QueryError::InvalidFrame) {
    Serial.printf("%s: %s.\n", name, frameErrorText(result.frameError));
    return false;
  }
  if (result.reply.payload[0] != 0x00) {
    Serial.printf("%s: scanner confirmation code 0x%02X", name,
                  result.reply.payload[0]);
    if (result.reply.payload[0] == 0x13) {
      Serial.print(" (incorrect password)");
    } else if (result.reply.payload[0] == 0x01) {
      Serial.print(" (scanner reports a received-packet error)");
    } else if (result.reply.payload[0] == 0x03) {
      Serial.print(" (image capture failed; reposition the finger)");
    } else if (result.reply.payload[0] == 0x06) {
      Serial.print(" (image too messy; clean and reposition the finger)");
    } else if (result.reply.payload[0] == 0x07) {
      Serial.print(" (too few usable fingerprint features)");
    } else if (result.reply.payload[0] == 0x15) {
      Serial.print(" (no usable fingerprint image)");
    } else if (result.reply.payload[0] == 0x0A) {
      Serial.print(" (the two enrollment scans did not agree; use the same finger)");
    } else if (result.reply.payload[0] == 0x18) {
      Serial.print(" (scanner flash-write error)");
    }
    Serial.println(".");
    return false;
  }
  return true;
}

void printReport() {
  if (!authenticated) {
    Serial.println("No authenticated connection. Send b to probe again.");
    return;
  }
  Serial.println("\n--- Scanner parameter report ---");
  Serial.println("Protocol: EF01 UART (AS608-compatible)");
  Serial.println("Model: not identified by these commands; AS608 is user supplied.");
  Serial.printf("ESP32 RX: GPIO%d; TX: GPIO%d; UART: 8N1\n",
                FINGERPRINT_RX_PIN, FINGERPRINT_TX_PIN);
  Serial.printf("Detected communication rate: %lu baud\n",
                static_cast<unsigned long>(connectedBaud));

  const uint8_t parametersCommand[] = {0x0F}; // ReadSysPara.
  const QueryResult parameters = query(parametersCommand, sizeof(parametersCommand));
  bool haveCapacity = false;
  uint16_t capacity = 0;
  if (checkQuery("ReadSysPara", parameters)) {
    if (parameters.reply.length != 17) {
      Serial.printf("Unexpected parameter payload: %u bytes; expected 17.\n",
                    static_cast<unsigned>(parameters.reply.length));
    } else {
      const uint8_t *p = parameters.reply.payload;
      capacity = fingerprint::read16(p + 5);
      haveCapacity = true;
      const uint16_t packetCode = fingerprint::read16(p + 13);
      const uint16_t baudMultiplier = fingerprint::read16(p + 15);
      const uint32_t reportedBaud = static_cast<uint32_t>(baudMultiplier) * 9600UL;
      Serial.printf("Status register: 0x%04X\n", fingerprint::read16(p + 1));
      Serial.printf("System ID: 0x%04X (protocol ID, not a unique serial number)\n",
                    fingerprint::read16(p + 3));
      Serial.printf("Template capacity: %u\n", capacity);
      Serial.printf("Security level: %u\n", fingerprint::read16(p + 7));
      Serial.printf("Device address: 0x%08lX\n",
                    static_cast<unsigned long>(fingerprint::read32(p + 9)));
      if (packetCode <= 3) {
        Serial.printf("Data packet size: %u bytes (code %u)\n",
                      static_cast<unsigned>(32U << packetCode), packetCode);
      } else {
        Serial.printf("Data packet size code: %u (unknown encoding)\n", packetCode);
      }
      Serial.printf("Reported UART rate: %lu baud (multiplier %u)\n",
                    static_cast<unsigned long>(reportedBaud), baudMultiplier);
      if (reportedBaud != connectedBaud) {
        Serial.println("Reported rate differs from the working rate; check the module manual.");
      }
    }
  }

  const uint8_t countCommand[] = {0x1D}; // TemplateNum.
  const QueryResult count = query(countCommand, sizeof(countCommand));
  if (checkQuery("TemplateNum", count)) {
    if (count.reply.length != 3) {
      Serial.println("Unexpected template-count payload; count unavailable.");
    } else {
      const uint16_t stored = fingerprint::read16(count.reply.payload + 1);
      Serial.printf("Stored templates: %u\n", stored);
      if (haveCapacity && stored <= capacity) {
        Serial.printf("Free template slots: %u\n", capacity - stored);
      } else if (haveCapacity) {
        Serial.println("Stored count exceeds reported capacity; check the module manual.");
      }
    }
  }
  Serial.println("Voltage, current, DPI, image dimensions, firmware version and");
  Serial.println("template byte size are not reported by these commands.");
}

bool checkOperationAck(const char *name, const QueryResult &result) {
  if (!checkQuery(name, result)) {
    return false;
  }
  if (result.reply.length != 1) {
    Serial.printf("%s: unexpected acknowledgement length.\n", name);
    return false;
  }
  return true;
}

bool readLibraryStats(uint16_t &capacity, uint16_t &stored) {
  const uint8_t command[] = {0x0F};
  const QueryResult result = query(command, sizeof(command));
  if (!checkQuery("ReadSysPara", result)) {
    return false;
  }
  if (result.reply.length != 17) {
    Serial.println("Cannot search: unexpected parameter payload.");
    return false;
  }
  capacity = fingerprint::read16(result.reply.payload + 5);
  if (capacity == 0) {
    Serial.println("Cannot search: scanner reports zero template capacity.");
    return false;
  }
  const uint8_t countCommand[] = {0x1D};
  const QueryResult count = query(countCommand, sizeof(countCommand));
  if (!checkQuery("TemplateNum", count)) {
    return false;
  }
  if (count.reply.length != 3) {
    Serial.println("Cannot search: unexpected template-count payload.");
    return false;
  }
  stored = fingerprint::read16(count.reply.payload + 1);
  Serial.printf("Stored templates: %u; search capacity: %u\n", stored, capacity);
  if (stored > capacity) {
    Serial.println("Cannot search: stored count exceeds reported capacity.");
    return false;
  }
  return true;
}

bool readSearchCapacity(uint16_t &capacity) {
  uint16_t stored = 0;
  if (!readLibraryStats(capacity, stored)) {
    return false;
  }
  if (stored == 0) {
    Serial.println("The scanner has no enrolled templates. Send e to enroll, or c to test capture.");
    return false;
  }
  return true;
}

bool waitForFinger(bool present) {
  Serial.println(present
      ? "Place a finger on the scanner. Waiting up to 20 seconds; x cancels."
      : "Lift your finger completely. Waiting up to 20 seconds; x cancels.");
  const uint32_t started = millis();
  const uint8_t imageCommand[] = {0x01}; // GenImg: scanner's volatile image buffer.
  while (true) {
    while (Serial.available()) {
      const int key = Serial.read();
      if (key == 'x' || key == 'X') {
        Serial.println("Capture cancelled.");
        return false;
      }
    }
    if (static_cast<uint32_t>(millis() - started) >= FINGER_WAIT_TIMEOUT_MS) {
      Serial.println(present ? "No finger detected before the wait expired. Retry the command."
                             : "Finger-removal wait expired. Lift your finger and retry e.");
      return false;
    }
    const QueryResult image = query(imageCommand, sizeof(imageCommand),
                                    SENSOR_OPERATION_TIMEOUT_MS);
    if (image.error == QueryError::None && image.reply.payload[0] == 0x02) {
      if (image.reply.length != 1) {
        Serial.println("GenImg: unexpected no-finger acknowledgement length.");
        return false;
      }
      if (!present) {
        Serial.println("Finger removed.");
        return true;
      }
      delay(100); // No finger yet; avoid flooding the scanner or console.
      continue;
    }
    if (!checkOperationAck("GenImg", image)) {
      return false;
    }
    if (present) {
      Serial.println("Image capture: PASS.");
      return true;
    }
    delay(100); // Finger is still present; wait for a separate second scan.
  }
}

void captureTest(bool matchExisting) {
  if (!authenticated) {
    Serial.println("No authenticated connection. Send b to probe again.");
    return;
  }
  Serial.println(matchExisting ? "\n--- Capture and match test ---"
                              : "\n--- Image capture test ---");
  uint16_t capacity = 0;
  if (matchExisting && !readSearchCapacity(capacity)) {
    return;
  }
  if (!waitForFinger(true)) {
    return;
  }
  if (!matchExisting) {
    Serial.println("Lift your finger. Send c to repeat, or m to capture and match.");
    return;
  }

  const uint8_t featureCommand[] = {0x02, 0x01}; // Img2Tz: character buffer 1.
  const QueryResult features = query(featureCommand, sizeof(featureCommand),
                                     SENSOR_OPERATION_TIMEOUT_MS);
  if (!checkOperationAck("Img2Tz", features)) {
    return;
  }
  Serial.println("Feature extraction: PASS.");
  // Search all reported slots. The count is capacity, not the occupied count,
  // because enrolled templates can be sparse (e.g. IDs 7, 42 and 149).
  const uint8_t searchCommand[] = {
      0x04, 0x01, 0x00, 0x00,
      static_cast<uint8_t>(capacity >> 8), static_cast<uint8_t>(capacity)};
  const QueryResult match = query(searchCommand, sizeof(searchCommand),
                                  SENSOR_OPERATION_TIMEOUT_MS);
  if (match.error == QueryError::None && match.reply.payload[0] == 0x09) {
    Serial.println("NO MATCH: this capture did not match an enrolled template.");
  } else if (checkQuery("Search", match)) {
    if (match.reply.length != 5) {
      Serial.println("Search: unexpected result payload; no match ID reported.");
      return;
    }
    const uint16_t id = fingerprint::read16(match.reply.payload + 1);
    const uint16_t score = fingerprint::read16(match.reply.payload + 3);
    if (id >= capacity) {
      Serial.println("Search: returned ID is outside the requested slot range.");
      return;
    }
    Serial.printf("MATCH: template ID=%u; confidence score=%u (raw sensor value).\n",
                  static_cast<unsigned>(id), static_cast<unsigned>(score));
  }
  Serial.println("Lift your finger. Send m to repeat with another finger.");
}

bool readIndexPage(uint8_t page, Reply &reply) {
  const uint8_t command[] = {0x1F, page}; // ReadIndexTable: 256 occupancy bits.
  const QueryResult result = query(command, sizeof(command));
  if (!checkQuery("ReadIndexTable", result)) {
    return false;
  }
  if (result.reply.length != 33) {
    Serial.println("ReadIndexTable: unexpected occupancy-table length.");
    return false;
  }
  reply = result.reply;
  return true;
}

bool findFreeSlot(uint16_t capacity, uint16_t stored, uint16_t &id) {
  if (stored == 0) {
    id = capacity > 1 ? 1 : 0;
    return true;
  }
  if (stored == capacity) {
    Serial.println("Template library is full. No enrollment slot is available.");
    return false;
  }
  bool zeroFree = false;
  for (uint32_t base = 0; base < capacity; base += 256) {
    Reply table;
    if (!readIndexPage(static_cast<uint8_t>(base / 256), table)) {
      Serial.println("Cannot prove a slot is free. Enrollment stopped; d can clear the library.");
      return false;
    }
    for (uint16_t bit = 0; bit < 256 && base + bit < capacity; ++bit) {
      if ((table.payload[1 + bit / 8] & (1U << (bit % 8))) == 0) {
        if (base + bit == 0) {
          zeroFree = true; // Prefer IDs starting at 1 when possible.
        } else {
          id = static_cast<uint16_t>(base + bit);
          return true;
        }
      }
    }
  }
  if (zeroFree) {
    id = 0;
    return true;
  }
  Serial.println("No free slot found in the occupancy table.");
  return false;
}

bool slotStillFree(uint16_t id) {
  const uint8_t command[] = {0x1D};
  const QueryResult count = query(command, sizeof(command));
  if (!checkQuery("TemplateNum", count) || count.reply.length != 3) {
    Serial.println("Cannot verify the slot before saving. Enrollment stopped.");
    return false;
  }
  if (fingerprint::read16(count.reply.payload + 1) == 0) {
    return true;
  }
  Reply table;
  if (!readIndexPage(static_cast<uint8_t>(id / 256), table)) {
    return false;
  }
  const uint16_t bit = id % 256;
  if (table.payload[1 + bit / 8] & (1U << (bit % 8))) {
    Serial.println("Selected slot is now occupied. Enrollment stopped before saving.");
    return false;
  }
  return true;
}

void enrollFinger() {
  if (!authenticated) {
    Serial.println("No authenticated connection. Send b to probe again.");
    return;
  }
  uint16_t capacity = 0, stored = 0, id = 0;
  if (!readLibraryStats(capacity, stored) || !findFreeSlot(capacity, stored, id)) {
    return;
  }
  Serial.printf("\n--- Enroll your finger in free slot %u ---\n", id);
  Serial.println("Scan 1 of 2: use the finger you want to register.");
  if (!waitForFinger(true)) {
    return;
  }
  const uint8_t firstFeatures[] = {0x02, 0x01};
  if (!checkOperationAck("Img2Tz buffer 1", query(firstFeatures, sizeof(firstFeatures),
                                                  SENSOR_OPERATION_TIMEOUT_MS))) {
    return;
  }
  if (!waitForFinger(false)) {
    return;
  }
  Serial.println("Scan 2 of 2: place the SAME finger again.");
  if (!waitForFinger(true)) {
    return;
  }
  const uint8_t secondFeatures[] = {0x02, 0x02};
  if (!checkOperationAck("Img2Tz buffer 2", query(secondFeatures, sizeof(secondFeatures),
                                                  SENSOR_OPERATION_TIMEOUT_MS))) {
    return;
  }
  const uint8_t combine[] = {0x05}; // RegModel: merge the two character buffers.
  if (!checkOperationAck("RegModel", query(combine, sizeof(combine),
                                             SENSOR_OPERATION_TIMEOUT_MS))) {
    return;
  }
  if (!slotStillFree(id)) {
    return;
  }
  const uint8_t save[] = {0x06, 0x01, static_cast<uint8_t>(id >> 8),
                        static_cast<uint8_t>(id)};
  const QueryResult saved = query(save, sizeof(save), SENSOR_OPERATION_TIMEOUT_MS);
  if (!checkOperationAck("Store", saved)) {
    Serial.println("Save not confirmed. Send r to check the library before retrying e.");
    return;
  }
  Serial.printf("ENROLLED: template ID=%u. Lift your finger, then send m to test it.\n", id);
  printReport();
}

bool confirmErase() {
  Serial.println("This permanently deletes ALL stored fingerprints. Type ERASE then Enter within 15 seconds; x cancels.");
  char text[16] = {};
  size_t length = 0;
  bool tooLong = false;
  const uint32_t started = millis();
  while (static_cast<uint32_t>(millis() - started) < ERASE_CONFIRM_TIMEOUT_MS) {
    if (!Serial.available()) {
      delay(1);
      continue;
    }
    const int key = Serial.read();
    if (length == 0 && (key == 'x' || key == 'X')) {
      Serial.println("Erase cancelled.");
      return false;
    }
    if (key == '\r' || key == '\n') {
      if (length == 0 && !tooLong) continue; // Ignore Enter after the d command.
      Serial.println("");
      if (!tooLong && strcmp(text, "ERASE") == 0) return true;
      Serial.println("Erase cancelled: confirmation did not match ERASE.");
      return false;
    }
    if ((key == 8 || key == 127) && length > 0 && !tooLong) {
      text[--length] = '\0';
      Serial.print("\b \b");
    } else if (key >= 32 && key <= 126) {
      Serial.printf("%c", key);
      if (length < sizeof(text) - 1) text[length++] = static_cast<char>(key);
      else tooLong = true;
    }
  }
  Serial.println("\nErase cancelled: confirmation timed out.");
  return false;
}

void eraseLibrary() {
  if (!authenticated) {
    Serial.println("No authenticated connection. Send b to probe again.");
    return;
  }
  uint16_t capacity = 0, stored = 0;
  if (!readLibraryStats(capacity, stored)) return;
  if (stored == 0) {
    Serial.println("The template library is already empty. Send e to enroll your finger.");
    return;
  }
  Serial.printf("\nErase request: %u stored templates.\n", stored);
  if (!confirmErase()) return;
  const uint8_t erase[] = {0x0D}; // Empty: delete all templates in sensor flash.
  if (!checkOperationAck("Empty", query(erase, sizeof(erase),
                                          SENSOR_OPERATION_TIMEOUT_MS))) {
    Serial.println("Erase not confirmed. Send r to check the library.");
    return;
  }
  const uint8_t countCommand[] = {0x1D};
  const QueryResult count = query(countCommand, sizeof(countCommand));
  if (!checkQuery("TemplateNum", count) || count.reply.length != 3) {
    Serial.println("Erase acknowledged, but count verification failed. Send r.");
    return;
  }
  if (fingerprint::read16(count.reply.payload + 1) != 0) {
    Serial.println("Erase acknowledged, but the scanner still reports stored templates. Send r.");
    return;
  }
  Serial.println("ERASED: stored templates=0. Send e to enroll your own finger.");
}

#include "template_transfer.h"

void probeScanner() {
  // 57600 first for AS608; all standard 9600 multiples, then common extensions.
  const uint32_t baudRates[] = {
      57600, 115200, 9600, 19200, 38400, 28800, 48000,
      67200, 76800, 86400, 96000, 105600, 230400, 460800};
  authenticated = false;
  connectedBaud = 0;
  uint8_t verifyCommand[5] = {0x13}; // VfyPwd; does not change the password.
  fingerprint::write32(verifyCommand + 1, FINGERPRINT_PASSWORD);
  Serial.println("\nProbing AS608-compatible scanners...");
  for (uint32_t baud : baudRates) {
    scanner.end();
    scanner.begin(baud, SERIAL_8N1, FINGERPRINT_RX_PIN, FINGERPRINT_TX_PIN);
    delay(80);
    Serial.printf("Trying %lu baud... ", static_cast<unsigned long>(baud));
    QueryResult result = query(verifyCommand, sizeof(verifyCommand));
    if (result.error == QueryError::Timeout) {
      // Retry once in case the module was still starting or an ACK was lost.
      result = query(verifyCommand, sizeof(verifyCommand));
    }
    if (result.error == QueryError::None) {
      connectedBaud = baud;
      if (!checkQuery("VfyPwd", result)) {
        Serial.println("A scanner responded. Check password/protocol; probing stopped.");
        return;
      }
      authenticated = true;
      Serial.println("authenticated.");
      printReport();
      return;
    }
    checkQuery("VfyPwd", result);
  }
  Serial.println("No compatible scanner found. Check power, common ground, TX/RX,");
  Serial.println("configured address/password and the scanner's actual protocol.");
  Serial.println("Unknown UART scanners using a different protocol need another driver.");
}

void printHelp() {
  Serial.println("\nr = read parameters/count again; b = repeat baud probe; h = help");
  Serial.println("c = capture image; m = capture and match existing templates; x = cancel finger wait");
  Serial.println("e = enroll your finger in a free slot; d = erase ALL templates after typing ERASE");
  Serial.println("t <ID> = export enrolled template; u = import via portable_template.py");
  Serial.println("Console is 115200 baud. Place a finger only when c or m prompts you.");
}

void setup() {
  Serial.begin(CONSOLE_BAUD);
  delay(1500); // Allow the scanner and USB console to start.
  Serial.println("\nESP32 fingerprint scanner diagnostic");
  printHelp();
  probeScanner();
}

void loop() {
  if (Serial.available()) {
    switch (Serial.read()) {
    case 'r': case 'R': printReport(); break;
    case 'b': case 'B': probeScanner(); break;
    case 'c': case 'C': captureTest(false); break;
    case 'm': case 'M': captureTest(true); break;
    case 'e': case 'E': enrollFinger(); break;
    case 'd': case 'D': eraseLibrary(); break;
    case 't': case 'T': exportTemplate(); break;
    case 'u': case 'U': importTemplate(); break;
    case 'h': case 'H': case '?': printHelp(); break;
    default: break;
    }
  }
  delay(10);
}
