"""Transfer opaque EF01 templates through the ESP32 USB serial console.

No database/network writes. Real template files belong in private storage.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import time
import uuid
import zlib
from dataclasses import asdict, dataclass
from datetime import datetime, timezone

FORMAT = "as608-ef01-opaque"
MAX_BYTES = 2048
HEX_LINE = re.compile(r"[0-9A-Fa-f]{2,64}\Z")


def canonical_uuid(value: str) -> str:
    parsed = uuid.UUID(value)
    if parsed.int == 0:
        raise ValueError("Use a nonzero UUID")
    return str(parsed)


def label(value: str) -> str:
    if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9_.-]{1,80}", value):
        raise ValueError("Labels must contain 1–80 letters, digits, _, . or -")
    return value


@dataclass(frozen=True)
class FingerprintTemplateRecord:
    schema_version: int
    template_id: str
    student_id: str
    finger_label: str
    template_format: str
    compatibility_group: str
    byte_length: int
    template_sha256: str
    template_base64: str
    exported_at: str
    source: dict

    @classmethod
    def create(cls, data: bytes, *, student_id: str, finger_label: str,
               scanner_id: str, gallery_id: str, compatibility_group: str,
               parameters: dict, template_id: str | None = None):
        if not 1 <= len(data) <= MAX_BYTES:
            raise ValueError("Template size is outside the 1–2048 byte transfer limit")
        return cls(
            schema_version=1,
            template_id=canonical_uuid(template_id or str(uuid.uuid4())),
            student_id=canonical_uuid(student_id),
            finger_label=label(finger_label),
            template_format=FORMAT,
            compatibility_group=label(compatibility_group),
            byte_length=len(data),
            template_sha256=hashlib.sha256(data).hexdigest(),
            template_base64=base64.b64encode(data).decode("ascii"),
            exported_at=datetime.now(timezone.utc).isoformat(),
            source={**parameters, "scanner_id": canonical_uuid(scanner_id),
                    "gallery_id": canonical_uuid(gallery_id),
                    "model_label": "AS608 (user supplied)", "firmware_version": None},
        )

    def validated_bytes(self) -> bytes:
        if type(self.schema_version) is not int or self.schema_version != 1:
            raise ValueError("Unsupported record schema version")
        if self.template_format != FORMAT:
            raise ValueError("Unsupported template format")
        canonical_uuid(self.template_id)
        canonical_uuid(self.student_id)
        label(self.finger_label)
        label(self.compatibility_group)
        if type(self.byte_length) is not int or not 1 <= self.byte_length <= MAX_BYTES:
            raise ValueError("Invalid template byte length")
        if not isinstance(self.template_base64, str) or len(self.template_base64) > 4 * ((MAX_BYTES + 2) // 3):
            raise ValueError("Invalid/oversized Base64 template")
        data = base64.b64decode(self.template_base64, validate=True)
        if len(data) != self.byte_length:
            raise ValueError("Template byte count disagrees with the record")
        if hashlib.sha256(data).hexdigest() != self.template_sha256:
            raise ValueError("Template SHA-256 checksum mismatch")
        if not isinstance(self.source, dict):
            raise ValueError("Invalid source metadata")
        canonical_uuid(self.source["scanner_id"])
        canonical_uuid(self.source["gallery_id"])
        validate_parameters(self.source)
        datetime.fromisoformat(self.exported_at)
        return data


def validate_parameters(parameters: dict):
    for name, minimum, maximum in (
        ("capacity", 1, 65535), ("slot_id", 0, 65534),
        ("security_level", 0, 65535), ("system_id", 0, 65535),
    ):
        value = parameters[name]
        if type(value) is not int or not minimum <= value <= maximum:
            raise ValueError(f"Invalid source {name}")
    if parameters["slot_id"] >= parameters["capacity"]:
        raise ValueError("Source slot exceeds capacity")
    if parameters["packet_bytes"] not in (32, 64, 128, 256):
        raise ValueError("Invalid source packet size")
    if not re.fullmatch(r"[0-9A-F]{8}", parameters["device_address"]):
        raise ValueError("Invalid source device address")


def read_record(path: Path) -> FingerprintTemplateRecord:
    if path.stat().st_size > 16384:
        raise ValueError("Record file exceeds the 16 KiB input limit")
    record = FingerprintTemplateRecord(**json.loads(path.read_text(encoding="utf-8")))
    record.validated_bytes()
    return record


def read_line(port, deadline: float) -> str:
    while time.monotonic() < deadline:
        raw = port.readline(256)
        if not raw:
            continue
        if len(raw) >= 256 or not raw.endswith(b"\n"):
            raise ValueError("Incomplete/oversized console line; transfer stopped")
        return raw.decode("ascii", errors="strict").strip()
    raise TimeoutError("ESP32 response timeout; check monitor is closed and firmware is current")


def wait_marker(port, marker: str, deadline: float) -> str:
    while True:
        line = read_line(port, deadline)
        if line.startswith("FPERROR"):
            raise ValueError("ESP32 rejected the transfer; inspect the serial monitor separately")
        if line.startswith(marker):
            return line


def receive_export(port, *, deadline: float):
    header = wait_marker(port, "FPBEGIN ", deadline).split()
    if len(header) != 8 or header[1] != "1":
        raise ValueError("Invalid export header/version")
    parameters = dict(zip(
        ("slot_id", "capacity", "security_level", "packet_bytes", "system_id"),
        map(int, header[2:7]),
    ))
    parameters["device_address"] = header[7]
    validate_parameters(parameters)
    data = bytearray()
    while True:
        line = read_line(port, deadline)
        if line.startswith("FPDATA "):
            encoded = line[7:]
            if not HEX_LINE.fullmatch(encoded) or len(encoded) % 2:
                raise ValueError("Malformed hex template line")
            data.extend(bytes.fromhex(encoded))
            if len(data) > MAX_BYTES:
                raise ValueError("Export exceeds the transfer limit")
        elif line.startswith("FPEND "):
            fields = line.split()
            if (len(fields) != 3 or not data or int(fields[1]) != len(data)
                    or not re.fullmatch(r"[0-9A-Fa-f]{8}", fields[2])
                    or int(fields[2], 16) != zlib.crc32(data)):
                raise ValueError("Export byte count/CRC mismatch")
            return bytes(data), parameters
        else:
            raise ValueError("Unexpected line inside template export")


def restore_bytes(port, data: bytes, *, deadline: float, on_ready=None) -> int:
    if not 1 <= len(data) <= MAX_BYTES:
        raise ValueError("Invalid restore size")
    checksum = zlib.crc32(data)
    port.write(f"u {len(data)} {checksum:08X}\n".encode("ascii"))
    ready = wait_marker(port, "FPREADY ", deadline).split()
    if len(ready) != 3 or int(ready[2]) != len(data) or not 0 <= int(ready[1]) <= 65534:
        raise ValueError("Invalid restore handshake")
    slot = int(ready[1])
    if on_ready is not None:
        on_ready(slot)  # Persist the planned binding before sending template data.
    for offset in range(0, len(data), 32):
        port.write((data[offset:offset + 32].hex() + "\n").encode("ascii"))
        # Keep the conventional ESP32 UART0 RX buffer from being flooded.
        port.flush()
        time.sleep(0.02)
    expected = f"FPSTORED {slot} {len(data)} {checksum:08X}"
    receipt = wait_marker(port, "FPSTORED ", deadline)
    if receipt != expected:
        raise ValueError("Restore receipt disagrees with requested bytes/slot")
    return slot


def connect(port_name: str):
    import serial  # Included in PlatformIO's Python environment; otherwise pip install pyserial.

    port = serial.Serial(port=None, baudrate=115200, timeout=1, write_timeout=5)
    port.dtr = False
    port.rts = False
    port.port = port_name
    port.open()
    try:
        time.sleep(2)
        port.reset_input_buffer()
        port.write(b"h\n")
        wait_marker(port, "t <ID>", time.monotonic() + 45)
        return port
    except Exception:
        port.close()
        raise


def write_json(stream, value: dict):
    stream.seek(0)
    json.dump(value, stream, indent=2)
    stream.write("\n")
    stream.truncate()
    stream.flush()
    os.fsync(stream.fileno())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    export = sub.add_parser("export", help="Read an enrolled scanner slot to a private JSON record")
    export.add_argument("--port", required=True)
    export.add_argument("--slot", required=True, type=int)
    export.add_argument("--student-id", required=True, type=canonical_uuid)
    export.add_argument("--finger", required=True, type=label)
    export.add_argument("--scanner-id", required=True, type=canonical_uuid)
    export.add_argument("--gallery-id", required=True, type=canonical_uuid)
    export.add_argument("--compatibility-group", required=True, type=label)
    export.add_argument("--template-id", type=canonical_uuid)
    export.add_argument("--out", required=True, type=Path)
    restore = sub.add_parser("restore", help="Write a validated record to a free scanner slot")
    restore.add_argument("--port", required=True)
    restore.add_argument("--record", required=True, type=Path)
    restore.add_argument("--target-scanner-id", required=True, type=canonical_uuid)
    restore.add_argument("--target-gallery-id", required=True, type=canonical_uuid)
    restore.add_argument("--compatibility-group", required=True, type=label)
    restore.add_argument("--receipt", required=True, type=Path)
    args = parser.parse_args()
    if args.command == "export":
        if not 0 <= args.slot <= 65534:
            parser.error("--slot must be in 0–65534 and within your scanner's capacity")
        if args.out.exists():
            parser.error("Output exists; choose a new path")
        with connect(args.port) as port:
            port.write(f"t {args.slot}\n".encode("ascii"))
            data, parameters = receive_export(port, deadline=time.monotonic() + 30)
        if parameters["slot_id"] != args.slot:
            raise ValueError("Export returned a different slot")
        record = FingerprintTemplateRecord.create(
            data, student_id=args.student_id, finger_label=args.finger,
            scanner_id=args.scanner_id, gallery_id=args.gallery_id,
            compatibility_group=args.compatibility_group, parameters=parameters,
            template_id=args.template_id,
        )
        record.validated_bytes()
        args.out.parent.mkdir(parents=True, exist_ok=True)
        with args.out.open("x", encoding="utf-8") as stream:
            write_json(stream, asdict(record))
        print(f"Exported {len(data)} bytes. Template UUID: {record.template_id}")
        print(f"Private record: {args.out.resolve()}")
    else:
        record = read_record(args.record)
        if record.compatibility_group != args.compatibility_group:
            raise ValueError("Compatibility group differs; no scanner write attempted")
        args.receipt.parent.mkdir(parents=True, exist_ok=True)
        receipt = {
            "schema_version": 1, "status": "pending", "template_id": record.template_id,
            "student_id": record.student_id, "finger_label": record.finger_label,
            "scanner_id": args.target_scanner_id, "gallery_id": args.target_gallery_id,
            "slot_id": None, "template_sha256": record.template_sha256,
            "started_at": datetime.now(timezone.utc).isoformat(),
        }
        # Reserve a durable receipt before any mutation. Failure leaves a pending
        # receipt for reconciliation, rather than claiming a successful binding.
        with args.receipt.open("x+", encoding="utf-8") as stream:
            write_json(stream, receipt)
            with connect(args.port) as port:
                def save_planned_slot(planned_slot):
                    receipt["slot_id"] = planned_slot
                    write_json(stream, receipt)

                slot = restore_bytes(port, record.validated_bytes(),
                                     deadline=time.monotonic() + 30, on_ready=save_planned_slot)
            receipt.update(status="verified", slot_id=slot,
                           verified_at=datetime.now(timezone.utc).isoformat())
            write_json(stream, receipt)
        print(f"Restored and read back exactly. New scanner slot: {slot}")
        print(f"Binding receipt: {args.receipt.resolve()}")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, KeyError, TypeError, OSError, TimeoutError) as error:
        raise SystemExit(f"Transfer failed: {error}")
