# Validation — 14 October 2026

## Host checks

Both suites compiled with GCC using `-std=c++11 -Wall -Wextra -Werror` and
completed successfully:

- `tests/protocol_test.cpp`: fixed packet fixtures for command encoding,
  parameters, 115200-baud arithmetic, template count, password error ACK,
  truncation, bounds, header/address/type rejection and checksum rejection.
- `tests/firmware_test.cpp`: the actual `src/main.cpp` compiled against a fake
  Arduino UART/clock. Simulation checked 115200-baud discovery, GPIO16/17,
  startup noise, decoded reports, console re-query, stale-value suppression
  after a corrupt parameter ACK, independent count reads, stopping on an
  incorrect password, and a bounded timeout scan.

`git diff --check` passed. The new diagnostic text files were also checked for
trailing whitespace.

## Supplied schematic inspection

The `.pdsprj` ZIP archive was inspected, including component/property strings
in `ROOT.DSN`. Those identify `ESP32-S3-DEVKITC-1` and the fingerprint block as
`VIRTUAL TERMINAL`, with `MODDLL=VTERM.DLL`. The library default is
`BAUDRATE=9600`, while the placed fingerprint terminal's instance properties
have `BAUDRATE=115200`. The project was not opened in Proteus, and a verified
connection netlist was not extracted.
GPIO16/17 are configurable defaults based on the photograph. The virtual
terminal cannot itself report specifications of a physical AS608.

## ESP32 builds

The `esp32-s3` build passed with PlatformIO Core 6.2.0,
`espressif32@6.12.0` and Arduino-ESP32 2.0.17. It produced `firmware.bin` for
ESP32-S3-DevKitC-1-N8, using 18,512 bytes of RAM and 267,509 bytes of application
flash. No project-source warnings were reported.

The conventional `esp32` / `esp32dev` profile also passed with the same platform
and Arduino framework versions. It produced `firmware.bin`, using 21,544 bytes
of RAM and 271,117 bytes of application flash. No project-source warnings were
reported. The combined PlatformIO command completed with exit code 0 and
`2 succeeded`:

```powershell
pio run -e esp32-s3 -e esp32
```

## Physical hardware

No firmware was uploaded, and no physical ESP32/scanner UART session was tested.
Module-reported values in the README are explicitly illustrative. Board variant,
connector labels, supply rating, UART logic levels and actual GPIO wiring must
match the physical hardware before running the test.
