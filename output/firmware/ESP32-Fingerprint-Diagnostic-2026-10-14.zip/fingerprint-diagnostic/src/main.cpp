#include <Arduino.h>
#include "config.h"
#include "fingerprint_protocol.h"

using fingerprint::Reply;
// UART1 is available on both the original ESP32 and ESP32-S3. UART0 remains
// available for the board's USB-to-UART console. Pins are assigned explicitly.
HardwareSerial scanner(1);
uint32_t connectedBaud = 0;
bool authenticated = false;

enum class QueryError { None, Timeout, InvalidFrame };
struct QueryResult {
  QueryError error = QueryError::None;
  fingerprint::FrameError frameError = fingerprint::FrameError::None;
  Reply reply;
};

bool readByte(uint8_t &value, uint32_t started) {
  while (static_cast<uint32_t>(millis() - started) < REPLY_TIMEOUT_MS) {
    if (scanner.available()) {
      value = static_cast<uint8_t>(scanner.read());
      return true;
    }
    delay(1);
  }
  return false;
}

QueryResult query(const uint8_t *command, size_t length) {
  QueryResult result;
  uint8_t frame[fingerprint::MAX_FRAME_SIZE] = {};
  const size_t requestSize = fingerprint::encodeCommand(
      frame, sizeof(frame), FINGERPRINT_ADDRESS, command, length);
  if (!requestSize) {
    result.error = QueryError::InvalidFrame;
    result.frameError = fingerprint::FrameError::Length;
    return result;
  }
  while (scanner.available()) {
    scanner.read();
  }
  scanner.write(frame, requestSize);
  scanner.flush();
  const uint32_t started = millis();

  // Ignore startup noise until an EF01 header is found, with one total timeout.
  bool haveEF = false;
  uint8_t byte = 0;
  while (true) {
    if (!readByte(byte, started)) {
      result.error = QueryError::Timeout;
      return result;
    }
    if (haveEF && byte == 0x01) {
      frame[0] = 0xEF;
      frame[1] = 0x01;
      break;
    }
    haveEF = (byte == 0xEF);
  }
  for (size_t i = 2; i < fingerprint::HEADER_SIZE; ++i) {
    if (!readByte(frame[i], started)) {
      result.error = QueryError::Timeout;
      return result;
    }
  }
  const size_t bodySize = fingerprint::read16(frame + 7);
  if (bodySize < 3 || bodySize > sizeof(frame) - fingerprint::HEADER_SIZE) {
    result.error = QueryError::InvalidFrame;
    result.frameError = fingerprint::FrameError::Length;
    return result;
  }
  const size_t frameSize = fingerprint::HEADER_SIZE + bodySize;
  for (size_t i = fingerprint::HEADER_SIZE; i < frameSize; ++i) {
    if (!readByte(frame[i], started)) {
      result.error = QueryError::Timeout;
      return result;
    }
  }
  result.frameError = fingerprint::decodeAck(
      frame, frameSize, FINGERPRINT_ADDRESS, result.reply);
  if (result.frameError != fingerprint::FrameError::None) {
    result.error = QueryError::InvalidFrame;
  }
  return result;
}

const char *frameErrorText(fingerprint::FrameError error) {
  switch (error) {
  case fingerprint::FrameError::Length: return "invalid packet length";
  case fingerprint::FrameError::Header: return "invalid packet header";
  case fingerprint::FrameError::Address: return "unexpected device address";
  case fingerprint::FrameError::PacketType: return "expected an ACK packet";
  case fingerprint::FrameError::Checksum: return "checksum mismatch";
  default: return "OK";
  }
}

bool checkQuery(const char *name, const QueryResult &result) {
  if (result.error == QueryError::Timeout) {
    Serial.printf("%s: timeout (no complete EF01 response).\n", name);
    return false;
  }
  if (result.error == QueryError::InvalidFrame) {
    Serial.printf("%s: %s.\n", name, frameErrorText(result.frameError));
    return false;
  }
  if (result.reply.payload[0] != 0x00) {
    Serial.printf("%s: scanner confirmation code 0x%02X", name,
                  result.reply.payload[0]);
    if (result.reply.payload[0] == 0x13) {
      Serial.print(" (incorrect password)");
    } else if (result.reply.payload[0] == 0x01) {
      Serial.print(" (scanner reports a received-packet error)");
    }
    Serial.println(".");
    return false;
  }
  return true;
}

void printReport() {
  if (!authenticated) {
    Serial.println("No authenticated connection. Send b to probe again.");
    return;
  }
  Serial.println("\n--- Scanner parameter report ---");
  Serial.println("Protocol: EF01 UART (AS608-compatible)");
  Serial.println("Model: not identified by these commands; AS608 is user supplied.");
  Serial.printf("ESP32 RX: GPIO%d; TX: GPIO%d; UART: 8N1\n",
                FINGERPRINT_RX_PIN, FINGERPRINT_TX_PIN);
  Serial.printf("Detected communication rate: %lu baud\n",
                static_cast<unsigned long>(connectedBaud));

  const uint8_t parametersCommand[] = {0x0F}; // ReadSysPara.
  const QueryResult parameters = query(parametersCommand, sizeof(parametersCommand));
  bool haveCapacity = false;
  uint16_t capacity = 0;
  if (checkQuery("ReadSysPara", parameters)) {
    if (parameters.reply.length != 17) {
      Serial.printf("Unexpected parameter payload: %u bytes; expected 17.\n",
                    static_cast<unsigned>(parameters.reply.length));
    } else {
      const uint8_t *p = parameters.reply.payload;
      capacity = fingerprint::read16(p + 5);
      haveCapacity = true;
      const uint16_t packetCode = fingerprint::read16(p + 13);
      const uint16_t baudMultiplier = fingerprint::read16(p + 15);
      const uint32_t reportedBaud = static_cast<uint32_t>(baudMultiplier) * 9600UL;
      Serial.printf("Status register: 0x%04X\n", fingerprint::read16(p + 1));
      Serial.printf("System ID: 0x%04X (protocol ID, not a unique serial number)\n",
                    fingerprint::read16(p + 3));
      Serial.printf("Template capacity: %u\n", capacity);
      Serial.printf("Security level: %u\n", fingerprint::read16(p + 7));
      Serial.printf("Device address: 0x%08lX\n",
                    static_cast<unsigned long>(fingerprint::read32(p + 9)));
      if (packetCode <= 3) {
        Serial.printf("Data packet size: %u bytes (code %u)\n",
                      static_cast<unsigned>(32U << packetCode), packetCode);
      } else {
        Serial.printf("Data packet size code: %u (unknown encoding)\n", packetCode);
      }
      Serial.printf("Reported UART rate: %lu baud (multiplier %u)\n",
                    static_cast<unsigned long>(reportedBaud), baudMultiplier);
      if (reportedBaud != connectedBaud) {
        Serial.println("Reported rate differs from the working rate; check the module manual.");
      }
    }
  }

  const uint8_t countCommand[] = {0x1D}; // TemplateNum.
  const QueryResult count = query(countCommand, sizeof(countCommand));
  if (checkQuery("TemplateNum", count)) {
    if (count.reply.length != 3) {
      Serial.println("Unexpected template-count payload; count unavailable.");
    } else {
      const uint16_t stored = fingerprint::read16(count.reply.payload + 1);
      Serial.printf("Stored templates: %u\n", stored);
      if (haveCapacity && stored <= capacity) {
        Serial.printf("Free template slots: %u\n", capacity - stored);
      } else if (haveCapacity) {
        Serial.println("Stored count exceeds reported capacity; check the module manual.");
      }
    }
  }
  Serial.println("Voltage, current, DPI, image dimensions, firmware version and");
  Serial.println("template byte size are not reported by these commands.");
}

void probeScanner() {
  // 57600 first for AS608; all standard 9600 multiples, then common extensions.
  const uint32_t baudRates[] = {
      57600, 115200, 9600, 19200, 38400, 28800, 48000,
      67200, 76800, 86400, 96000, 105600, 230400, 460800};
  authenticated = false;
  connectedBaud = 0;
  uint8_t verifyCommand[5] = {0x13}; // VfyPwd; does not change the password.
  fingerprint::write32(verifyCommand + 1, FINGERPRINT_PASSWORD);
  Serial.println("\nProbing AS608-compatible scanners...");
  for (uint32_t baud : baudRates) {
    scanner.end();
    scanner.begin(baud, SERIAL_8N1, FINGERPRINT_RX_PIN, FINGERPRINT_TX_PIN);
    delay(80);
    Serial.printf("Trying %lu baud... ", static_cast<unsigned long>(baud));
    QueryResult result = query(verifyCommand, sizeof(verifyCommand));
    if (result.error == QueryError::Timeout) {
      // Retry once in case the module was still starting or an ACK was lost.
      result = query(verifyCommand, sizeof(verifyCommand));
    }
    if (result.error == QueryError::None) {
      connectedBaud = baud;
      if (!checkQuery("VfyPwd", result)) {
        Serial.println("A scanner responded. Check password/protocol; probing stopped.");
        return;
      }
      authenticated = true;
      Serial.println("authenticated.");
      printReport();
      return;
    }
    checkQuery("VfyPwd", result);
  }
  Serial.println("No compatible scanner found. Check power, common ground, TX/RX,");
  Serial.println("configured address/password and the scanner's actual protocol.");
  Serial.println("Unknown UART scanners using a different protocol need another driver.");
}

void printHelp() {
  Serial.println("\nr = read parameters/count again; b = repeat baud probe; h = help");
  Serial.println("Console is 115200 baud. No finger placement is needed.");
}

void setup() {
  Serial.begin(CONSOLE_BAUD);
  delay(1500); // Allow the scanner and USB console to start.
  Serial.println("\nESP32 fingerprint scanner diagnostic");
  printHelp();
  probeScanner();
}

void loop() {
  if (Serial.available()) {
    switch (Serial.read()) {
    case 'r': case 'R': printReport(); break;
    case 'b': case 'B': probeScanner(); break;
    case 'h': case 'H': case '?': printHelp(); break;
    default: break;
    }
  }
  delay(10);
}
