#include <assert.h>
#include "../src/main.cpp"

uint32_t fakeMillis = 0;
HardwareSerial Serial(0);

const std::vector<uint8_t> OK = {
    0xEF, 0x01, 0xFF, 0xFF, 0xFF, 0xFF, 0x07, 0x00, 0x03, 0x00, 0x00, 0x0A};
const std::vector<uint8_t> PARAMETERS = {
    0xEF, 0x01, 0xFF, 0xFF, 0xFF, 0xFF, 0x07, 0x00, 0x13,
    0x00, 0x00, 0x00, 0x00, 0x09, 0x00, 0x64, 0x00, 0x03,
    0xFF, 0xFF, 0xFF, 0xFF, 0x00, 0x02, 0x00, 0x0C, 0x04, 0x94};
const std::vector<uint8_t> COUNT = {
    0xEF, 0x01, 0xFF, 0xFF, 0xFF, 0xFF, 0x07, 0x00, 0x05,
    0x00, 0x00, 0x02, 0x00, 0x0E};
const std::vector<uint8_t> WRONG_PASSWORD = {
    0xEF, 0x01, 0xFF, 0xFF, 0xFF, 0xFF, 0x07, 0x00, 0x03, 0x13, 0x00, 0x1D};

int main() {
  std::vector<uint8_t> commands;
  // Emulate an unknown compatible module at 115200, including startup noise.
  scanner.onWrite = [&](uint32_t baud, const uint8_t *request, size_t size) {
    assert(size >= 12);
    const uint8_t command = request[9];
    assert(command == 0x13 || command == 0x0F || command == 0x1D);
    commands.push_back(command);
    if (baud != 115200) return std::vector<uint8_t>{};
    auto response = command == 0x13 ? OK : command == 0x0F ? PARAMETERS : COUNT;
    response.insert(response.begin(), {0x55, 0xEF, 0xEF});
    return response;
  };
  setup();
  assert(authenticated && connectedBaud == 115200);
  assert(scanner.rxPin == 16 && scanner.txPin == 17);
  assert(Serial.output.find("Reported UART rate: 115200 baud") != std::string::npos);
  assert(Serial.output.find("Template capacity: 100") != std::string::npos);
  assert(Serial.output.find("Stored templates: 2") != std::string::npos);
  assert(Serial.output.find("Free template slots: 98") != std::string::npos);

  // A later bad parameter ACK must not display previous values, while the
  // independent count query can still complete successfully.
  Serial.output.clear();
  scanner.onWrite = [](uint32_t, const uint8_t *request, size_t) {
    auto response = request[9] == 0x0F ? PARAMETERS : COUNT;
    if (request[9] == 0x0F) response.back() ^= 1;
    return response;
  };
  Serial.incoming.push_back('r');
  loop();
  assert(Serial.output.find("checksum mismatch") != std::string::npos);
  assert(Serial.output.find("Template capacity:") == std::string::npos);
  assert(Serial.output.find("Stored templates: 2") != std::string::npos);
  assert(Serial.output.find("Free template slots:") == std::string::npos);

  Serial.output.clear();
  unsigned requests = 0;
  scanner.onWrite = [&](uint32_t, const uint8_t *request, size_t) {
    assert(request[9] == 0x13);
    ++requests;
    return WRONG_PASSWORD;
  };
  probeScanner();
  assert(requests == 1 && !authenticated);
  assert(Serial.output.find("incorrect password") != std::string::npos);

  Serial.output.clear();
  scanner.onWrite = [](uint32_t, const uint8_t *, size_t) {
    return std::vector<uint8_t>{};
  };
  const uint32_t started = fakeMillis;
  probeScanner();
  assert(!authenticated && connectedBaud == 0);
  assert(fakeMillis - started < 25000);
  assert(Serial.output.find("No compatible scanner found") != std::string::npos);
  puts("Firmware simulations passed: baud detection, pins, reporting, re-query, corrupt ACK, password and timeout.");
}
