# Validation — 14 October 2026

## Host checks

Both suites compiled with GCC using `-std=c++11 -Wall -Wextra -Werror` and
completed successfully:

- `tests/protocol_test.cpp`: fixed packet fixtures for command encoding,
  parameters, 115200-baud arithmetic, template count, password error ACK,
  truncation, bounds, header/address/type rejection and checksum rejection.
- `tests/firmware_test.cpp`: the actual `src/main.cpp` compiled against a fake
  Arduino UART/clock. Simulation checked 115200-baud discovery, GPIO16/17,
  startup noise, decoded reports, console re-query, stale-value suppression
  after a corrupt parameter ACK, independent count reads, stopping on an
  incorrect password, and a bounded timeout scan. The capture/match update also
  checked capture-only mode, no-finger polling, full 150-slot search with nine
  occupied entries, feature extraction, synthetic match ID/score, no-match,
  messy-image errors, checksum rejection, malformed results, out-of-range IDs,
  empty libraries, cancellation and distinct operation/finger-wait timeouts.

`git diff --check` passed. The new diagnostic text files were also checked for
trailing whitespace.

## Supplied schematic inspection

The `.pdsprj` ZIP archive was inspected, including component/property strings
in `ROOT.DSN`. Those identify `ESP32-S3-DEVKITC-1` and the fingerprint block as
`VIRTUAL TERMINAL`, with `MODDLL=VTERM.DLL`. The library default is
`BAUDRATE=9600`, while the placed fingerprint terminal's instance properties
have `BAUDRATE=115200`. The project was not opened in Proteus, and a verified
connection netlist was not extracted.
GPIO16/17 are configurable defaults based on the photograph. The virtual
terminal cannot itself report specifications of a physical AS608.

## ESP32 builds

The `esp32-s3` build passed with PlatformIO Core 6.2.0,
`espressif32@6.12.0` and Arduino-ESP32 2.0.17. It produced `firmware.bin` for
ESP32-S3-DevKitC-1-N8, using 18,512 bytes of RAM and 267,509 bytes of application
flash for the initial metadata diagnostic. The capture/match build also passed,
using 18,512 bytes RAM and 269,805 bytes application flash. No project-source
warnings were reported.

The conventional `esp32` / `esp32dev` profile also passed with the same platform
and Arduino framework versions. It produced `firmware.bin`, using 21,544 bytes
of RAM and 271,117 bytes of application flash. No project-source warnings were
reported. The capture/match build also passed, using 21,544 bytes RAM and
273,405 bytes application flash. The combined PlatformIO command completed with exit code 0 and
`2 succeeded`:

```powershell
pio run -e esp32-s3 -e esp32
```

## Physical hardware

The user confirmed the physical board is a regular ESP32, so `default_envs`
was changed to `esp32`. Windows enumeration detected a connected CP2102 USB to
UART Bridge Controller (`USB\\VID_10C4&PID_EA60`) initially reporting problem
code 28. After the user installed the driver, PlatformIO enumerated the bridge
successfully on COM12.

The user then supplied a serial-console report from the physical ESP32 and
scanner. This is user-reported hardware evidence; the assistant did not upload
firmware or operate the scanner. The report confirms a successful EF01 UART
parameter/count read with these module-reported values:

| Field | Reported value |
| --- | --- |
| ESP32 UART pins | RX GPIO16, TX GPIO17 |
| UART format | 8N1 |
| Working and reported scanner baud | 57600 |
| Status register | 0x0000 |
| System ID | 0x0000 |
| Template capacity | 150 |
| Security level | 3 |
| Device address | 0xFFFFFFFF |
| Data packet size | 128 bytes (code 2) |
| Stored templates | 9 |
| Free template slots | 141 |

The console remains at 115200 baud. Model identity remains user supplied as
AS608. Capture and matching are now available through `c` and `m`; their
physical-hardware results remain pending. These operations use volatile image
and character buffers and search the existing template library. Template export
and enrolment remain outside this diagnostic. Supply voltage/current, image dimensions, DPI,
firmware version and complete template byte size remain unverified. The README
example numbers remain explicitly illustrative, rather than this hardware log.
