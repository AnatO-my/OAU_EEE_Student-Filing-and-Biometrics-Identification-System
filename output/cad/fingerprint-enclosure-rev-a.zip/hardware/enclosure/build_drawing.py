"""Generate A3 landscape technical drawing from the CAD parameter file."""
import json
import math
from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A3, landscape
from reportlab.lib.colors import HexColor, white

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1]
P = json.loads((ROOT / "parameters.json").read_text())
OUT = REPO / "output" / "pdf" / "fingerprint-enclosure-technical-drawing.pdf"
OUT.parent.mkdir(parents=True, exist_ok=True)
PW, PH = landscape(A3)
C = canvas.Canvas(str(OUT), pagesize=(PW, PH))
C.setTitle("Fingerprint terminal enclosure - approximate technical drawing, revision A")
NAVY, GREY, ORANGE = map(HexColor, ["#233b4c", "#687d89", "#e56a43"])
W, D, H = (P[k] for k in ("body_width", "depth", "height"))
ANG = math.radians(P["front_angle_from_vertical_deg"])
K, COS = math.tan(ANG), math.cos(ANG)
FH = H / COS


def text(x, y, value, size=11, bold=False, color=NAVY):
    C.setFillColor(color)
    C.setFont("Helvetica-Bold" if bold else "Helvetica", size)
    C.drawString(x, y, str(value))


def line(x1, y1, x2, y2, color=NAVY, width=0.8, dash=None):
    C.setStrokeColor(color); C.setLineWidth(width)
    C.setDash(dash or [])
    C.line(x1, y1, x2, y2)
    C.setDash([])


def rect(x, y, w, h, color=NAVY, fill=None):
    C.setStrokeColor(color); C.setLineWidth(1)
    C.setFillColor(fill or white)
    C.rect(x, y, w, h, stroke=1, fill=bool(fill))


def circle(x, y, r, color=NAVY):
    C.setStrokeColor(color); C.setLineWidth(0.8); C.circle(x, y, r)
    line(x-r-3, y, x+r+3, y, GREY, 0.4)
    line(x, y-r-3, x, y+r+3, GREY, 0.4)


def poly(points, color=NAVY, dash=None):
    C.setStrokeColor(color); C.setLineWidth(1); C.setDash(dash or [])
    path = C.beginPath(); path.moveTo(*points[0])
    for p in points[1:]: path.lineTo(*p)
    path.close(); C.drawPath(path)
    C.setDash([])


def dimh(x1, x2, object_y, y, label):
    for x in (x1, x2): line(x, object_y, x, y + (5 if y > object_y else -5), GREY, 0.4)
    line(x1, y, x2, y, GREY, 0.5)
    for x in (x1, x2): line(x-3, y-3, x+3, y+3, GREY, 0.6)
    C.setFont("Helvetica", 10)
    tw = C.stringWidth(label, "Helvetica", 10)
    C.setFillColor(white); C.rect((x1+x2-tw)/2-3, y-2, tw+6, 13, fill=1, stroke=0)
    text((x1+x2-tw)/2, y+1, label, 10)


def dimv(y1, y2, object_x, x, label):
    for y in (y1, y2): line(object_x, y, x + (5 if x > object_x else -5), y, GREY, 0.4)
    line(x, y1, x, y2, GREY, 0.5)
    for y in (y1, y2): line(x-3, y-3, x+3, y+3, GREY, 0.6)
    C.saveState(); C.translate(x-4, (y1+y2)/2); C.rotate(90)
    C.setFont("Helvetica", 10); C.setFillColor(white)
    tw = C.stringWidth(label, "Helvetica", 10); C.rect(-tw/2-3, -2, tw+6, 13, fill=1, stroke=0)
    text(-tw/2, 1, label, 10); C.restoreState()


def note(x, y, lines, size=11, leading=18):
    for i, s in enumerate(lines): text(x, y-i*leading, s, size)


def table(x, y, widths, rows, height=26):
    for r, row in enumerate(rows):
        xx = x
        for w, value in zip(widths, row):
            rect(xx, y-(r+1)*height, w, height, GREY, HexColor("#eef3f5") if r==0 else None)
            text(xx+8, y-(r+1)*height+9, value, 10, r==0)
            xx += w


def header(page, title, scale):
    rect(24, 24, PW-48, PH-48, GREY)
    text(44, PH-57, "EEE / FINGERPRINT TERMINAL", 17, True)
    text(44, PH-82, title, 12)
    text(PW-350, PH-57, "REV A | 07 OCT 2026", 11, True)
    text(PW-350, PH-78, "APPROXIMATE - VERIFY HARDWARE FIT", 10, True, ORANGE)
    line(24, PH-98, PW-24, PH-98, GREY)
    line(24, 68, PW-24, 68, GREY)
    text(44, 45, "Units: mm | " + scale + " | A3 landscape | Print at 100%; use written dimensions.", 10)
    text(PW-185, 45, f"SHEET {page} OF 4", 10, True)


def face_features(x, y, scale, projected=False):
    vf = COS if projected else 1
    for name, center, size in (("OLED", P["oled_center_uv"], P["oled_window"]),
                              ("ADAPTER", P["sensor_center_uv"], P["sensor_body_opening"])):
        u, v = center; w, h = size
        rect(x+(u-w/2)*scale, y+(v-h/2)*scale*vf, w*scale, h*scale*vf)
        text(x+(u-w/2)*scale, y+(v+h/2)*scale*vf+7, name, 9)
    for uv in P["button_centers_uv"]:
        u,v=uv; circle(x+u*scale, y+v*scale*vf, P["button_hole_diameter"]/2*scale)
    for uv in P["led_centers_uv"]:
        u,v=uv; circle(x+u*scale, y+v*scale*vf, P["led_hole_diameter"]/2*scale)
    su,sv=P["sensor_center_uv"]
    for du in (-19,19):
        for dv in (-23,23): circle(x+(su+du)*scale,y+(sv+dv)*scale*vf,scale)
    bu,bv=P["buzzer_center_uv"]
    for n in range(7):
        u,v=(bu,bv) if n==6 else (bu+4*math.cos(n*math.pi/3),bv+4*math.sin(n*math.pi/3))
        circle(x+u*scale,y+v*scale*vf,0.8*scale)


# Sheet 1: true orthographic views and rendered CAD appearance.
header(1, "OVERALL ENCLOSURE / DESK CONFIGURATION", "Orthographic views 1:1.417; preview NTS")
s=2; x=110; y=445
rect(x,y,W*s,D*s); rect(x+W*s,y,40*s,D*s,ORANGE); rect(x+190*s,y,3*s,D*s,ORANGE)
line(x,y+K*H*s,x+W*s,y+K*H*s,GREY,0.6,dash=[5,3])
text(x,y+D*s+52,"TOP VIEW",12,True)
text(x+W*s+7,y+D*s/2,"POD",9,True,ORANGE)
dimh(x,x+W*s,y+D*s,y+D*s+28,"150 main body")
dimh(x,x+193*s,y,y-32,"193 assembled width")
dimv(y,y+D*s,x,x-37,"100 depth")
x=110;y=140
rect(x,y,W*s,H*s); rect(x+W*s,y,43*s,H*s,ORANGE)
line(x,y+3*s,x+W*s,y+3*s,GREY)
face_features(x,y,s,True)
text(x,y+H*s+30,"FRONT VIEW (PROJECTED)",12,True)
dimh(x,x+193*s,y,y-30,"193")
dimv(y,y+H*s,x,x-37,"100 height")
x=760;y=140
poly([(x,y),(x+D*s,y),(x+D*s,y+H*s),(x+K*H*s,y+H*s)])
poly([(x+(K*3+3.2/COS)*s,y+3*s),(x+(D-3.2)*s,y+3*s),
      (x+(D-3.2)*s,y+(H-3.2)*s),(x+(K*(H-3.2)+3.2/COS)*s,y+(H-3.2)*s)],GREY,[4,3])
line(x,y,x,y+H*s,GREY,0.5,[3,3])
text(x,y+H*s+30,"RIGHT VIEW / SHAPE",12,True)
dimh(x,x+K*H*s,y+H*s,y+H*s+15,"36.40 setback")
dimh(x,x+D*s,y,y-30,"100")
text(x+5,y+115,"20 deg from vertical",10)
text(x+90,y+55,"Wall 3.2 nominal",10)
text(x+90,y+35,"Base / cover 3.0",10)
C.drawImage(str(ROOT/"enclosure-preview.png"),590,430,width=545,height=295,preserveAspectRatio=True,anchor="c")
note(590,414,["Reference adapted from Sketchfab 'Fingerprint' by brixdeguzman9.",
               "Layout follows the visible preview; dimensions are a new engineering draft.",
               "Orange side feature is a separate battery compartment with screw cover."],10,16)
C.showPage()

# Sheet 2: face-plane machining layout; coordinates are not projected heights.
header(2,"FRONT FACE / SKETCH COORDINATES","Face view 1:1; coordinate table is authoritative")
s=72/25.4;x=108;y=230
rect(x,y,W*s,FH*s); face_features(x,y,s)
text(x,y+FH*s+66,"VIEW NORMAL TO THE SLOPED FACE",12,True)
dimh(x,x+W*s,y+FH*s,y+FH*s+28,"150")
dimv(y,y+FH*s,x,x-38,f"{FH:.2f} face length")
line(x-12,y,x+25,y,ORANGE,1.2);line(x,y-12,x,y+25,ORANGE,1.2)
text(x-5,y-28,"DATUM: theoretical lower-left front corner",10,True,ORANGE)
text(x+225,y-49,"u -> right; v -> up the sloped face",10)
rows=[["Feature","Center u, v","Opening / pattern"],
      ["OLED window","48, 77","24 x 13 rectangle"],
      ["Sensor opening","114, 57","32 x 40 rectangle"],
      ["Sensor adapter","114, 57","44 x 52 x 2 plate"],
      ["Adapter pilots","95/133, 34/80","4 x DIA 2.0 in body"],
      ["Buttons (3)","28/48/68, 40","3 x DIA 6.5"],
      ["LEDs (3)","37/48/59, 58","3 x DIA 3.2"],
      ["Buzzer grille","48, 21","7 x DIA 1.6; 6 on DIA 8 PCD"]]
table(610,622,[135,145,225],rows)
note(610,355,["All cutouts run perpendicular to the face through the wall.",
              "Conversion to body axes (x, y, z):",
              "x = u - 75; y = v sin(20 deg); z = v cos(20 deg).",
              "The theoretical datum lies at z=0; body begins at z=3.",
              "Do not locate face features using the projected front-view height.",
              "Button apertures assume small caps / custom plungers.",
              "Panel-mount switches may need much larger holes.",
              "OLED: assumes a 0.96-inch display, not confirmed by resolution.",
              "Reserve 35 x 35 x 12 behind OLED; measure hole pattern.",
              "Add a measured OLED bracket and sensor clamp before fabrication."],11,22)
text(610,112,"Dimension references: Waveshare OLED specs | RAKwireless GROW R307 specs",9)
C.linkURL("https://www.waveshare.com/wiki/0.96inch_OLED_Module",(700,110,826,123),relative=0)
C.linkURL("https://store.rakwireless.com/products/rak12001-fingerprint-module",(835,110,1106,123),relative=0)
C.showPage()

# Sheet 3: closure details and screw coordinates.
header(3,"BASE, BATTERY COVER & SENSOR ADAPTER","Detail sketches 1:1.417; holes per coordinate tables")
s=2;x=92;y=417
rect(x,y,W*s,D*s)
for xx in (-68,68):
    for yy in (14,86): circle(x+(xx+75)*s,y+yy*s,1.7*s)
for xx in (-57,15):
    for yy in (46,84): rect(x+(xx+75-4)*s,y+(yy-4)*s,8*s,8*s,GREY)
text(x,y+D*s+55,"BASE / INSIDE VIEW",12,True)
dimh(x,x+W*s,y+D*s,y+D*s+25,"150")
dimv(y,y+D*s,x,x-35,"100")
note(x,y-27,["Base 3 thick; four 8 x 8 x 4 support pads.",
             "4 x DIA 3.4 clearance; body pilots DIA 2.6, depth 10.",
             "Screw x = -68 / +68; y = 14 / 86 (body axes).",
             "Pad x = -57 / +15; y = 46 / 84.",
             "Board retention holes / clips require measured board."],10,17)
x=538;y=417
poly([(x,y),(x+D*s,y),(x+D*s,y+H*s),(x+K*H*s,y+H*s)],ORANGE)
for z in (12,88):
    for yy in (K*z+7,D-7): circle(x+yy*s,y+z*s,1.7*s)
text(x,y+H*s+55,"BATTERY COVER / OUTER VIEW",12,True)
dimh(x,x+D*s,y,y-25,"100 depth")
dimv(y,y+H*s,x+D*s,x+D*s+30,"100 height")
note(x,y-54,["Cover 3 thick; outer side profile matches housing.",
             "4 x DIA 3.4; pod bosses OD 11, length 14.",
             "At z=12: y=11.37 / 93.00.",
             "At z=88: y=39.03 / 93.00.",
             "Coordinates use front lower theoretical corner.",
             "Cover pilots DIA 2.6, blind depth 11 in pod."],10,17)
x=878;y=453
rect(x,y,44*s,52*s)
rect(x+(44-20)/2*s,y+(52-22)/2*s,20*s,22*s)
for xx in (3,41):
    for yy in (3,49):circle(x+xx*s,y+yy*s,1.2*s)
text(x-5,y+52*s+45,"SENSOR ADAPTER",12,True)
dimh(x,x+44*s,y,y-24,"44")
dimv(y,y+52*s,x+44*s,x+44*s+25,"52")
note(857,397,["Plate thickness 2; 4 x DIA 2.4.",
              "Hole pitch 38 x 46; edge offset 3.",
              "R307 provisional window: 20 x 22.",
              "AS608 provisional window: 15 x 19.",
              "Do not infer sensor clamp dimensions",
              "from the optical window size."],10,17)
line(70,230,PW-70,230,GREY)
note(80,202,["COMMON DETAILS",
             "Outer profile corners: R4. Base corners: R4. Wall: 3.2 nominal. Sharp cutout corners are intentional in this draft.",
             "Battery pod attaches at y=62, z=15 and 85: body DIA 3.4 clearance; pod DIA 2.6 pilot (provisional M3 fastening).",
             "Wire passage: DIA 8 at y=60, z=22 through both dividing walls. Add a grommet / edge protection for the actual cable.",
             "Power entry: rear face, x=-45, z=25; DIA 8 provisional. Adjust to the selected low-voltage connector.",
             "All pilot sizes are starting values for printed plastic; confirm screw type, engagement and fit on a small coupon."],11,19)
C.showPage()

# Sheet 4: planning allowances and a concrete recreation workflow.
header(4,"INTERNAL SPACE / RECREATION GUIDE","Planning envelopes NTS; no hardware fit claim")
rows=[["Item","Provisional reservation (mm)","Mounting / fit action"],
      ["ESP32 development board","60 x 35 x 20","Measure variant, antenna end and USB access"],
      ["0.96-inch OLED PCB","35 x 35 x 12","Confirm display size, window and screw pattern"],
      ["R307 / AS608 + cable","28 across face x 60 inward x 35 up face","Measure module and cable bend; add clamp"],
      ["DS3231 breakout","40 x 26 x 12","Keep coin-cell holder accessible"],
      ["Buzzer","DIA 15 x 12","Locate behind grille; add measured bracket"],
      ["Button switch bodies","12 x 12 x 15 each","Confirm caps, travel and switch retention"],
      ["Veroboard / mini breadboard","100 x 50 base plan","Use left side of base; add measured retention"],
      ["Side battery holder + pack","25 across x 42 depth x 75 height","Choose holder, regulation and charge hardware"]]
table(60,704,[160,340,560],rows,29)
text(60,417,"PROPOSED PLACEMENT",12,True)
note(60,389,["Veroboard zone: x=-60 to +40; y=40 to 90, on support pads (top z=7).",
             "Keep tall parts clear of the right sensor envelope; any board area beneath it must stay below z=12.",
             "OLED and three switch bodies mount behind the left front face; keep their wiring removable.",
             "Battery envelope: x=83 to 108; y=45 to 87; z=12 to 87, in the separate pod.",
             "Pod nominal internal width 36.8; bosses reduce usable space near cover corners.",
             "Full-size breadboards are not reserved. Add room if using a large breadboard or multiple boards.",
             "Leave clearance at ESP32 antenna and cable plugs; no selected power/battery circuit is modeled."],11,21)
text(60,206,"RECREATE IN SOLIDWORKS / FREECAD / FUSION",12,True)
note(60,179,["1. Set mm. Sketch side trapezoid (y,z): (0,0), (100,0), (100,100), (36.40,100).",
             "2. Main body: clip bottom at z=3, extrude 150 across x, round side-profile corners R4; hollow with 3.2 walls and open bottom.",
             "3. Add the 150 x 100 x 3 removable base, four bosses and support pads from sheet 3.",
             "4. Sketch directly on sloped face. Place sheet-2 cutouts by u,v; cut normal to face. Make separate 2-thick sensor adapter.",
             "5. Extrude matching side profile 40 for battery pod; hollow toward outer side; make 3-thick cover and sheet-3 screw details.",
             "6. Add rear power entry, attachment holes and wire passage. Measure parts, add retention brackets, then check interference."],10,18)
C.showPage()
C.save()
print(OUT)
