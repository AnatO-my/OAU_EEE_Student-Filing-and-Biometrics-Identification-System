"""Parametric solid CAD enclosure. All units mm. Run with CadQuery 2.8.

Exports STEP solids, a colored assembled STEP, STL parts, preview, and a
geometry-validation report. Electronics shown in the preview are illustrative.
"""
import json
import math
from pathlib import Path

import cadquery as cq

ROOT = Path(__file__).resolve().parent
P = json.loads((ROOT / "parameters.json").read_text())
OUT = ROOT / "cad"
OUT.mkdir(exist_ok=True)
W, D, H, T, B = (P[k] for k in ["body_width", "depth", "height", "wall", "base_thickness"])
A = math.radians(P["front_angle_from_vertical_deg"])
S, C, K = math.sin(A), math.cos(A), math.tan(A)
PW, CT = P["battery_pod_width"], P["battery_cover_thickness"]


def profile(x, width, bottom=0, inset=0, radius=0):
    """Side-profile extrusion along X; inset is perpendicular wall offset."""
    lo, hi = bottom, H - inset
    f = inset / C
    points = [(K * lo + f, lo), (D - inset, lo),
              (D - inset, hi), (K * hi + f, hi)]
    q = cq.Workplane("YZ", origin=(x, 0, 0)).polyline(points).close().extrude(width)
    return q.edges("|X").fillet(radius) if radius else q


def front_plane(u=0, v=0, offset=0):
    return cq.Plane(origin=(-W / 2 + u, S * v - C * offset, C * v + S * offset),
                    xDir=(1, 0, 0), normal=(0, -C, S))


def face_rect(center, size, offset=1, thickness=None):
    return cq.Workplane(front_plane(*center, offset)).rect(*size).extrude(-(thickness or T + 3))


def face_hole(center, diameter, offset=1, thickness=None):
    return cq.Workplane(front_plane(*center, offset)).circle(diameter / 2).extrude(-(thickness or T + 3))


def yz_hole(x, y, z, dia, length):
    return cq.Workplane("YZ", origin=(x, y, z)).circle(dia / 2).extrude(length)


def box(x, y, z, dx, dy, dz):
    return cq.Workplane("XY").box(dx, dy, dz).translate((x, y, z))


body = profile(-W / 2, W, B, radius=P["corner_radius"])
# Open bottom; internal corners remain square to preserve full wall thickness.
body = body.cut(profile(-W / 2 + T, W - 2 * T, B - 1, T))
body = body.cut(face_rect(P["oled_center_uv"], P["oled_window"]))
body = body.cut(face_rect(P["sensor_center_uv"], P["sensor_body_opening"]))
for uv in P["button_centers_uv"]:
    body = body.cut(face_hole(uv, P["button_hole_diameter"]))
for uv in P["led_centers_uv"]:
    body = body.cut(face_hole(uv, P["led_hole_diameter"]))
bu, bv = P["buzzer_center_uv"]
for n in range(7):
    uv = (bu, bv) if n == 6 else (bu + 4 * math.cos(n * math.pi / 3), bv + 4 * math.sin(n * math.pi / 3))
    body = body.cut(face_hole(uv, 1.6))
# Removable adapter retained with four small screws; hole pitch is independent
# of the unknown sensor's own mounting pattern.
su, sv = P["sensor_center_uv"]
adapter_screws = [(su + u, sv + v) for u in (-19, 19) for v in (-23, 23)]
for uv in adapter_screws:
    body = body.cut(face_hole(uv, 2.0))
# Rear external low-voltage power entry: connector size must be measured.
power_x, power_z = P["power_center_xz"]
rear_plane = cq.Plane(origin=(power_x, D + 1, power_z), xDir=(1, 0, 0), normal=(0, -1, 0))
body = body.cut(cq.Workplane(rear_plane).circle(P["power_hole_diameter"] / 2).extrude(T + 3))

base = box(0, D / 2, B / 2, W, D, B).edges("|Z").fillet(P["corner_radius"])
base_screws = [(x, y) for x in (-68, 68) for y in (14, 86)]
for x, y in base_screws:
    boss = cq.Workplane("XY", origin=(x, y, B)).circle(5.5).extrude(13)
    body = body.union(boss)
    body = body.cut(cq.Workplane("XY", origin=(x, y, B - 0.1)).circle(1.3).extrude(10))
    base = base.cut(cq.Workplane("XY", origin=(x, y, -1)).circle(1.7).extrude(B + 2))
# Veroboard support pads. Mounting holes deliberately deferred until board is measured.
for x in (-57, 15):
    for y in (46, 84):
        base = base.union(box(x, y, B + 2, 8, 8, 4))

# Side battery compartment, open toward the removable outer cover.
pod = profile(W / 2, PW, radius=P["corner_radius"])
pod = pod.cut(profile(W / 2 + T, PW - T + 1, T, T))
cover = profile(W / 2 + PW, CT, radius=P["corner_radius"])
pod_screws = [(K * z + 7, z) for z in (12, 88)] + [(D - 7, z) for z in (12, 88)]
for y, z in pod_screws:
    pod = pod.union(yz_hole(W / 2 + PW - 14, y, z, 11, 14))
    pod = pod.cut(yz_hole(W / 2 + PW - 11, y, z, 2.6, 12))
    cover = cover.cut(yz_hole(W / 2 + PW - 1, y, z, 3.4, CT + 2))
# Shared 8mm wiring passage through both separating walls.
body = body.cut(yz_hole(W / 2 - T - 1, 60, 22, 8, 2 * T + 2))
pod = pod.cut(yz_hole(W / 2 - 1, 60, 22, 8, T + 2))
# Attach pod from inside main body; M3 hardware into printed pilots is provisional.
for y, z in ((62, 15), (62, 85)):
    body = body.cut(yz_hole(W / 2 - T - 1, y, z, 3.4, T + 2))
    pod = pod.cut(yz_hole(W / 2 - 1, y, z, 2.6, T + 2))


def adapter(window):
    q = face_rect(P["sensor_center_uv"], P["sensor_adapter_size"], offset=2, thickness=2)
    q = q.cut(face_rect(P["sensor_center_uv"], window, offset=3, thickness=4))
    for uv in adapter_screws:
        q = q.cut(face_hole(uv, 2.4, offset=3, thickness=4))
    return q


parts = {"main_body": body, "base": base, "battery_pod": pod,
         "battery_cover": cover, "sensor_adapter_r307": adapter(P["r307_adapter_window"]),
         "sensor_adapter_as608": adapter(P["as608_adapter_window"])}
colors = {"main_body": (0.32, 0.39, 0.43), "base": (0.18, 0.23, 0.27),
          "battery_pod": (0.96, 0.35, 0.22), "battery_cover": (0.96, 0.35, 0.22),
          "sensor_adapter_r307": (0.16, 0.20, 0.23)}
assembly = cq.Assembly(name="desk_fingerprint_terminal_revision_A")
report = {"revision": P["revision"], "units": "mm", "parts": {}, "intersections_mm3": {}}
assembled_names = list(colors)
for name, q in parts.items():
    shape = q.val()
    assert shape.isValid() and len(q.solids().vals()) == 1 and shape.Volume() > 0, name
    cq.exporters.export(q, str(OUT / f"{name}.step"))
    cq.exporters.export(q, str(OUT / f"{name}.stl"), tolerance=0.08, angularTolerance=0.15)
    imported = cq.importers.importStep(str(OUT / f"{name}.step")).val()
    assert imported.isValid() and abs(imported.Volume() - shape.Volume()) < 0.01, name
    bb = shape.BoundingBox()
    report["parts"][name] = {"valid": True, "solid_count": 1, "step_round_trip": True,
                             "volume_mm3": round(shape.Volume(), 3),
                             "bounding_box_mm": [round(v, 3) for v in (bb.xlen, bb.ylen, bb.zlen)]}
    if name in colors:
        assembly.add(q, name=name, color=cq.Color(*colors[name]))
for i, name in enumerate(assembled_names):
    for other in assembled_names[i + 1:]:
        volume = parts[name].intersect(parts[other]).val().Volume()
        report["intersections_mm3"][name + " / " + other] = round(volume, 6)
        assert volume < 0.01, (name, other, volume)
assembly.export(str(OUT / "enclosure_assembly.step"))
reservations = {
    "veroboard_plate_only": box(-10, 65, 8, 100, 50, 2),
    "sensor_and_cable": face_rect(P["sensor_center_uv"], [28, 35], offset=-T-0.5, thickness=60),
    "battery_pack_holder": box(95.5, 66, 49.5, 25, 42, 75),
}
report["illustrative_reservation_collisions_mm3"] = {}
for name, envelope in reservations.items():
    collisions = {part: round(envelope.intersect(parts[part]).val().Volume(), 6)
                  for part in assembled_names}
    report["illustrative_reservation_collisions_mm3"][name] = collisions
    assert all(volume < 0.01 for volume in collisions.values()), (name, collisions)
report["status"] = "solid geometry verified; hardware fit and manufacture unverified"
(OUT / "validation.json").write_text(json.dumps(report, indent=2))


def render():
    import vtk
    from PIL import Image, ImageDraw, ImageFont
    renderer = vtk.vtkRenderer()
    renderer.SetBackground(0.96, 0.97, 0.98)

    def draw(q, color, shift=(0, 0, 0)):
        vertices, faces = q.val().tessellate(0.3, 0.25)
        points = vtk.vtkPoints()
        for p in vertices:
            points.InsertNextPoint(p.x + shift[0], p.y + shift[1], p.z + shift[2])
        triangles = vtk.vtkCellArray()
        for face in faces:
            triangle = vtk.vtkTriangle()
            for i, idx in enumerate(face): triangle.GetPointIds().SetId(i, idx)
            triangles.InsertNextCell(triangle)
        data = vtk.vtkPolyData(); data.SetPoints(points); data.SetPolys(triangles)
        normals = vtk.vtkPolyDataNormals(); normals.SetInputData(data)
        normals.SetFeatureAngle(30); normals.Update()
        mapper = vtk.vtkPolyDataMapper(); mapper.SetInputConnection(normals.GetOutputPort())
        actor = vtk.vtkActor(); actor.SetMapper(mapper)
        rgb = tuple(int(color.lstrip("#")[i:i+2], 16)/255 for i in (0,2,4)) if isinstance(color,str) else color
        actor.GetProperty().SetColor(*rgb)
        actor.GetProperty().SetAmbient(0.3); actor.GetProperty().SetDiffuse(0.7)
        renderer.AddActor(actor)

    for name in assembled_names:
        draw(parts[name], colors[name])
    # Cosmetic representations in the holes; excluded from manufactured STEP.
    draw(face_rect(P["oled_center_uv"], [23.6, 12.6], offset=0.05, thickness=0.5), "#1ca8d2")
    draw(face_rect(P["sensor_center_uv"], [19.6, 21.6], offset=2.05, thickness=0.5), "#284890")
    for uv in P["button_centers_uv"]:
        draw(cq.Workplane(front_plane(*uv, 1.2)).circle(2.8).extrude(-2), "#b9a5cc")
    for uv, color in zip(P["led_centers_uv"], ["#42c487", "#eead39", "#e15d65"]):
        draw(cq.Workplane(front_plane(*uv, 0.8)).circle(1.5).extrude(-1), color)
    camera = renderer.GetActiveCamera()
    camera.SetPosition(270, -350, 225); camera.SetFocalPoint(17, 50, 48)
    camera.SetViewUp(0,0,1); camera.ParallelProjectionOn(); camera.SetParallelScale(105)
    window = vtk.vtkRenderWindow(); window.SetOffScreenRendering(1)
    window.SetSize(1800, 1040); window.AddRenderer(renderer); window.SetMultiSamples(8)
    renderer.ResetCameraClippingRange(); window.Render()
    capture = vtk.vtkWindowToImageFilter(); capture.SetInput(window); capture.Update()
    writer = vtk.vtkPNGWriter(); writer.SetInputConnection(capture.GetOutputPort())
    writer.SetFileName(str(ROOT / "enclosure-preview.png")); writer.Write(); window.Finalize()
    im = Image.open(ROOT / "enclosure-preview.png").convert("RGB")
    draw_text = ImageDraw.Draw(im)
    font_path = str(REPO_FONT) if (REPO_FONT := ROOT.parents[1] / "docs/fonts/FunnelDisplay-Regular.ttf").exists() else "C:/Windows/Fonts/arial.ttf"
    title_font = ImageFont.truetype(font_path, 36); body_font = ImageFont.truetype(font_path, 23)
    draw_text.text((60,40), "FINGERPRINT TERMINAL / CAD DRAFT A", font=title_font, fill="#253641")
    draw_text.text((60,95), "Desk enclosure with side battery pod | 193 W x 100 D x 100 H mm", font=body_font, fill="#536672")
    draw_text.text((60,990), "Approximate layout. Component visuals are illustrative; measure hardware before fabrication.", font=body_font, fill="#536672")
    im.save(ROOT / "enclosure-preview.png")


render()
print(json.dumps(report, indent=2))
